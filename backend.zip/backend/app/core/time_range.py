from calendar import monthrange
from datetime import date, datetime, time, timedelta
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

from fastapi import HTTPException

from app.modules.analysis.evidence import UTC


def resolve_range(
    mode: str,
    preset: str | None = None,
    month: str | None = None,
    year: int | str | None = None,
    start_date: date | None = None,
    end_date: date | None = None,
    timezone_name: str = "UTC",
    now: datetime | None = None,
):
    try:
        tz = ZoneInfo(timezone_name)
    except (ZoneInfoNotFoundError, ValueError) as err:
        raise HTTPException(422, "Invalid IANA timezone") from err
    now = (now or datetime.now(UTC)).astimezone(tz)
    if mode == "preset":
        if preset not in ("1m", "3m", "6m", "1y", "all") or any(
            v is not None for v in (month, year, start_date, end_date)
        ):
            raise HTTPException(422, "Invalid preset parameters")
        if preset == "all":
            lower = datetime(1970, 1, 1, tzinfo=tz)
            upper = now
        else:
            # Rolling calendar months, anchored to the current local date/time.
            months = {"1m": 1, "3m": 3, "6m": 6, "1y": 12}[preset]
            y, m = now.year, now.month - months
            while m <= 0:
                y -= 1
                m += 12
            if y < 1:
                raise HTTPException(422, "Preset range is out of bounds")
            d = min(now.day, monthrange(y, m)[1])
            lower = now.replace(year=y, month=m, day=d)
            upper = now
    elif mode == "month":
        if month is None or any(
            v is not None for v in (preset, year, start_date, end_date)
        ):
            raise HTTPException(422, "Invalid month parameters")
        import re

        if not re.fullmatch(r"\d{4}-(0[1-9]|1[0-2])", month):
            raise HTTPException(422, "month must be YYYY-MM")
        y, m = map(int, month.split("-"))
        if y < 1 or y > 9998:
            raise HTTPException(422, "Invalid year")
        lower = datetime(y, m, 1, tzinfo=tz)
        upper = datetime(y + (m == 12), m % 12 + 1, 1, tzinfo=tz)
    elif mode == "year":
        if year is None or any(
            v is not None for v in (preset, month, start_date, end_date)
        ):
            raise HTTPException(422, "Invalid year parameters")
        try:
            y = int(year)
        except (ValueError, TypeError):
            raise HTTPException(422, "year must be an integer") from None
        if y < 1 or y > 9998:
            raise HTTPException(422, "Invalid year (must be 1-9998)")
        lower = datetime(y, 1, 1, tzinfo=tz)
        upper = datetime(y + 1, 1, 1, tzinfo=tz)
    elif mode == "custom":
        if (
            not start_date
            or not end_date
            or preset is not None
            or month is not None
            or year is not None
        ):
            raise HTTPException(422, "Invalid custom parameters")
        if start_date > end_date or (end_date - start_date).days > 3660:
            raise HTTPException(422, "Invalid date range (max 3660 days)")
        if end_date == date.max:
            raise HTTPException(422, "End date is out of bounds")
        lower = datetime.combine(start_date, time.min, tz)
        upper = datetime.combine(end_date + timedelta(days=1), time.min, tz)
    else:
        raise HTTPException(422, "Invalid mode")
    return lower.astimezone(UTC), upper.astimezone(UTC)
